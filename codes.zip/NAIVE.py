'''
Program: Naive Bayes Classification using Iris Dataset
Operations:
1. Import dataset
2. Display first 5 rows
3. Check samples of each class
4. Check null values
5. Visualize data
6. Train-test split
7. Apply Naive Bayes model
8. Predict and calculate accuracy
9. Show confusion matrix & classification report
'''

import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt
from sklearn.datasets import load_iris
from sklearn.model_selection import train_test_split
from sklearn.naive_bayes import GaussianNB
from sklearn.metrics import accuracy_score, confusion_matrix, classification_report

# ---------------------------------------------------
# 1. Import Dataset
# ---------------------------------------------------
iris = load_iris()
df = pd.DataFrame(iris.data, columns=iris.feature_names)
df["Species"] = iris.target

# ---------------------------------------------------
# 2. Display the first 5 rows
# ---------------------------------------------------
print("First 5 rows:\n", df.head(), "\n")

# ---------------------------------------------------
# 3. Number of samples per class
# ---------------------------------------------------
print("Class sample counts:\n", df["Species"].value_counts(), "\n")

# ---------------------------------------------------
# 4. Check for null values
# ---------------------------------------------------
print("Null values:\n", df.isnull().sum(), "\n")

# ---------------------------------------------------
# 5. Visualizations
# ---------------------------------------------------
sns.countplot(x="Species", data=df)
plt.title("Class Distribution")
plt.show()

sns.pairplot(df, hue="Species")
plt.suptitle("Feature Relationships", y=1.02)
plt.show()

# ---------------------------------------------------
# 6. Train-test split
# ---------------------------------------------------
X = df.drop("Species", axis=1)
y = df["Species"]

X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=42
)

# ---------------------------------------------------
# 7. Naive Bayes Model
# ---------------------------------------------------
model = GaussianNB()
model.fit(X_train, y_train)

# ---------------------------------------------------
# 8. Predictions & Accuracy
# ---------------------------------------------------
y_pred = model.predict(X_test)
accuracy = accuracy_score(y_test, y_pred)

print("Accuracy:", accuracy, "\n")

# ---------------------------------------------------
# 9. Confusion Matrix & Classification Report
# ---------------------------------------------------
print("Confusion Matrix:\n", confusion_matrix(y_test, y_pred), "\n")
print("Classification Report:\n", classification_report(y_test, y_pred))
