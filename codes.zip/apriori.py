# apriori_demo.py
# pip install mlxtend pandas matplotlib

import random
import pandas as pd
from mlxtend.preprocessing import TransactionEncoder
from mlxtend.frequent_patterns import apriori, association_rules
import matplotlib.pyplot as plt

# -----------------------------
# Create a random sample dataset and save to CSV
# -----------------------------
items_pool = [
    "milk", "bread", "butter", "eggs", "cheese", "apple",
    "banana", "cereal", "chips", "coke", "water", "chocolate",
    "yogurt", "coffee", "tea"
]

# create 20 sample transactions (varying lengths 1..5)
transactions_sample = []
for _ in range(20):
    k = random.randint(1, 5)  # items per transaction
    tx = random.sample(items_pool, k)
    transactions_sample.append(tx)

# Save as CSV where each row is "item1,item2,..." to mimic your original format
df_sample = pd.DataFrame({"items": [",".join(t) for t in transactions_sample]})
df_sample.to_csv("market_basket.csv", index=False)

print("Sample dataset saved to market_basket.csv (20 transactions).")

# -----------------------------
# 1. Import Dataset
# -----------------------------
df = pd.read_csv("market_basket.csv")   # each row contains items separated by commas

# -----------------------------
# 2. Convert rows into list of items (transactions)
# -----------------------------
# df.values.tolist() gives list-of-lists like [[ "milk,bread" ], [ "bread,eggs" ], ...]
transactions = df.values.tolist()
transactions = [str(t[0]).split(",") for t in transactions]  # now each element is a list of items

# -----------------------------
# 3. Display first 5 rows
# -----------------------------
print("\nFirst 5 rows of the raw CSV:")
print(df.head())

# -----------------------------
# 4. Check for null values
# -----------------------------
print("\nNull values per column:")
print(df.isnull().sum())

# -----------------------------
# 5. Visualize top 10 most frequent items
# -----------------------------
flat_list = [item.strip() for sublist in transactions for item in sublist]
item_counts = pd.Series(flat_list).value_counts().head(10)

plt.figure(figsize=(8,5))
item_counts.plot(kind='bar')
plt.title("Top 10 Most Purchased Items (sample)")
plt.xlabel("Items")
plt.ylabel("Frequency")
plt.tight_layout()
plt.show()

# -----------------------------
# 6. Apply Apriori Algorithm (one-hot encoding -> apriori)
# -----------------------------
te = TransactionEncoder()
te_data = te.fit(transactions).transform(transactions)  # shape: (n_transactions, n_unique_items)
df_tf = pd.DataFrame(te_data, columns=te.columns_)       # boolean dataframe for apriori

# Generate frequent itemsets (min_support set low because dataset is small)
frequent_items = apriori(df_tf, min_support=0.1, use_colnames=True)

print("\nFrequent itemsets (support >= 0.1):")
print(frequent_items.sort_values(by="support", ascending=False).reset_index(drop=True))

# ------------------ -----------
# 7. Generate association rules
# -----------------------------
rules = association_rules(frequent_items, metric="confidence", min_threshold=0.2)

# Sort by confidence (and then lift) and display top 10
rules_sorted = rules.sort_values(by=["confidence", "lift"], ascending=[False, False]).reset_index(drop=True)

print("\nTop association rules (top 10):")
if rules_sorted.empty:
    print("No rules found with the chosen thresholds. Try lowering min_support or min_threshold.")
else:
    # print only the most useful columns
    display_cols = ["antecedents", "consequents", "support", "confidence", "lift"]
    print(rules_sorted[display_cols].head(10))
