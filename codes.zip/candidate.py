import pandas as pd

# Load dataset using pandas
df = pd.read_csv("playtennis.csv")

# Convert to list format
data = df.values.tolist()

rows = data
total_attributes = len(rows[0]) - 1

# Initialize S and G
S = ["0"] * total_attributes
G = [["?"] * total_attributes]

# Candidate-Elimination Algorithm
for row in rows:
    attributes = row[:-1]
    label = str(row[-1]).strip().lower()

    if label == "yes":   # POSITIVE EXAMPLE → generalize S
        for i in range(total_attributes):
            if S[i] == "0":
                S[i] = attributes[i]
            elif S[i] != attributes[i]:
                S[i] = "?"
        # Remove inconsistent hypotheses from G
        G = [g for g in G if all(g[i] == "?" or g[i] == S[i] for i in range(total_attributes))]

    else:  # NEGATIVE EXAMPLE → specialize G
        new_G = [] 
        for g in G:
            for i in range(total_attributes):
                if g[i] == "?":
                    if S[i] != attributes[i]:
                        new_h = g.copy()
                        new_h[i] = S[i]
                        new_G.append(new_h)
        G = new_G

print("Final Specific Boundary (S):", S)
print("Final General Boundary (G):", G)