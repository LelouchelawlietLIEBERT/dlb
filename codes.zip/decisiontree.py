import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.tree import DecisionTreeClassifier
from sklearn.metrics import classification_report, confusion_matrix
from sklearn.preprocessing import LabelEncoder
import seaborn as sns
import matplotlib.pyplot as plt

# ----------------------------------
# 1. Load dataset
# ----------------------------------
df = pd.read_csv("playtennis.csv")

print(df.head())
print(df.shape)
print(df.isnull().sum())
print(df.info())

# ----------------------------------
# 2. Encode categorical attributes (CORRECT WAY)
# ----------------------------------
encoders = {}   # dictionary to store one encoder per column

for col in df.columns:
    le = LabelEncoder()
    df[col] = le.fit_transform(df[col])
    encoders[col] = le   # store encoder for later use

# ----------------------------------
# 3. Split features and target
# ----------------------------------
X = df.iloc[:, :-1]
y = df.iloc[:, -1]

# ----------------------------------
# 4. Train-test split
# ----------------------------------
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.3, random_state=42
)

# ----------------------------------
# 5. Train Decision Tree using ID3
# ----------------------------------
model = DecisionTreeClassifier(criterion="entropy")
model.fit(X_train, y_train)

# ----------------------------------
# 6. Prediction on test data
# ----------------------------------
y_pred = model.predict(X_test)

print(f"\nModel Accuracy: {model.score(X_test, y_test)}\n")
print("Classification Report:\n")
print(classification_report(y_test, y_pred))

# ----------------------------------
# 7. Confusion Matrix
# ----------------------------------
cnf = confusion_matrix(y_test, y_pred)
sns.heatmap(cnf, annot=True, fmt="d")
plt.show()

# ----------------------------------
# 8. Classify a new sample
# Example: Sunny, Cool, High, Strong
# ----------------------------------
new_sample = [[
    encoders["Outlook"].transform(["Sunny"])[0],
    encoders["Temperature"].transform(["Cool"])[0],
    encoders["Humidity"].transform(["High"])[0],
    encoders["Wind"].transform(["Strong"])[0]
]]

prediction = model.predict(new_sample)

print("\nNew Sample Prediction:")
print("Play Tennis = YES" if prediction[0] == 1 else "Play Tennis = NO")
