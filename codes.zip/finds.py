# find_s_demo.py
# pip install pandas

import pandas as pd

# -----------------------------
# 1. Load Dataset
# -----------------------------
df = pd.read_csv("enjoysport.csv")

print("First 5 rows of dataset:\n")
print(df.head(), "\n")

print("Null values:\n")
print(df.isnull().sum(), "\n")

# -----------------------------
# 2. Convert to list of rows
# -----------------------------
data = df.values.tolist()

# Last column = target (yes/no)
num_attributes = len(data[0]) - 1

# -----------------------------
# 3. Initialize most specific hypothesis
# -----------------------------
hypothesis = ["0" for _ in range(num_attributes)]

# -----------------------------
# 4. FIND-S Algorithm
# -----------------------------
print("Processing training samples...\n")

for row in data:
    attributes = row[:-1]
    target = row[-1]

    if target.lower() == "yes":   # Only positive examples
        for i in range(num_attributes):
            if hypothesis[i] == "0":
                hypothesis[i] = attributes[i]   # First positive example
            elif hypothesis[i] != attributes[i]:
                hypothesis[i] = "?"             # Generalize

print("Final Most Specific Hypothesis:\n")
print(hypothesis)
