'''
Program: Gradient Descent on California Housing Dataset
Operations:
1. Import the dataset
2. Display first 5 rows
3. Check the number of samples in each attribute (no class labels here)
4. Check for null values
5. Visualize data (histograms + scatter plot)
6. Obtain covariance & correlation
7. Train-test split
8. Apply manual Gradient Descent Regression
9. Predict accuracy using R2-score
'''

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.datasets import fetch_california_housing
from sklearn.model_selection import train_test_split
from sklearn.metrics import r2_score
import seaborn as sns

# -------------------------------------
# 1. Import Dataset
# -------------------------------------
data = fetch_california_housing(as_frame=True)
df = data.frame

# -------------------------------------
# 2. Display first 5 rows
# -------------------------------------
print("First 5 Rows:\n", df.head(), "\n")

# -------------------------------------
# 3. Display column names (dataset has no class labels)
# -------------------------------------
print("Columns:", df.columns, "\n")

# -------------------------------------
# 4. Check Null Values
# -------------------------------------
print("Null Values:\n", df.isnull().sum(), "\n")

# -------------------------------------
# 5. Data Visualization
# -------------------------------------
df.hist(figsize=(12, 10))
plt.suptitle("Feature Distributions", fontsize=14)
plt.show()

plt.scatter(df["MedInc"], df["MedHouseVal"], alpha=0.3)
plt.xlabel("Median Income")
plt.ylabel("Median House Value")
plt.title("Income vs House Value")
plt.show()

# -------------------------------------
# 6. Covariance & Correlation
# -------------------------------------
print("Covariance Matrix:\n", df.cov(), "\n")
print("Correlation Matrix:\n", df.corr(), "\n")

# -------------------------------------
# 7. Prepare Data for Regression
# -------------------------------------
X = df[["MedInc"]].values  # using only 1 feature (simple regression)
y = df["MedHouseVal"].values

X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=42
)

# -------------------------------------
# 8. Manual Gradient Descent
# -------------------------------------
m = 0   # slope
c = 0   # intercept
lr = 0.01
epochs = 10
n = len(X_train)

for i in range(epochs):
    y_pred = m * X_train + c

    # Partial derivatives
    d_c = (2/n) * np.sum(y_pred - y_train)
    d_m = (2/n) * np.sum((y_pred - y_train) * X_train)

    # Update parameters
    m -= lr * d_m
    c -= lr * d_c
    
    if (i+1)%2==0:
        print(f"{i+1}epoch m={m} c={c}")


print(f"Final Model: y = {m}x + {c}")

# -------------------------------------
# 9. Accuracy
# -------------------------------------
y_test_pred = m * X_test + c
accuracy = r2_score(y_test, y_test_pred)

print(f"R2 Score (Accuracy): {accuracy}")
