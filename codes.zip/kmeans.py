from sklearn.datasets import make_blobs
from sklearn.cluster import KMeans
import numpy as np
import matplotlib.pyplot as plt

# --------------------------------------
# 1. Create Dataset (make_blobs)
# --------------------------------------
X, y_true = make_blobs(n_samples=200, centers=3, random_state=42)

# --------------------------------------
# 2. Apply K-Means with 3 clusters
# --------------------------------------
kmeans = KMeans(n_clusters=3, random_state=42)
kmeans.fit(X)

# --------------------------------------
# 3. Print Centroids
# --------------------------------------
print("Cluster Centers (Centroids):")
print(kmeans.cluster_centers_)

# --------------------------------------
# 4. Predict cluster for new data point
# --------------------------------------
new_point = np.array([[0.906, 0.606]])
prediction = kmeans.predict(new_point)

print("\nNew Point:", new_point)
print("Predicted Cluster:", prediction[0])

# --------------------------------------
# 5. Visualization
# --------------------------------------
plt.scatter(X[:, 0], X[:, 1], c=kmeans.labels_, cmap='viridis', alpha=0.6)
plt.scatter(kmeans.cluster_centers_[:, 0], 
            kmeans.cluster_centers_[:, 1],
            s=200, c='red', marker='X', label='Centroids')

plt.scatter(new_point[:, 0], new_point[:, 1], 
            c='black', marker='*', s=200, label='New Point')

plt.title("K-Means Clustering with 3 Centers")
plt.legend()
plt.show()
