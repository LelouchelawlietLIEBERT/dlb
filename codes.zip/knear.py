# ---------------------------------------------
# K-Nearest Neighbors (KNN) Classification
# Using Iris Dataset
# ---------------------------------------------

from sklearn.datasets import load_iris
from sklearn.neighbors import KNeighborsClassifier
from sklearn.metrics import classification_report, confusion_matrix
from sklearn.model_selection import train_test_split
import matplotlib.pyplot as plt
import pandas as pd
import seaborn as sns

# ---------------------------------------------
# 1. Load the Iris dataset
# ---------------------------------------------
iris = load_iris()

# Convert dataset to pandas DataFrame
df = pd.DataFrame(iris.data, columns=iris.feature_names)
df['species'] = iris.target

# Display first 5 rows and dataset shape
print("First 5 rows of the dataset:\n", df.head(), "\n")
print("Dataset shape:", df.shape, "\n")

# ---------------------------------------------
# 2. Separate features and target variable
# ---------------------------------------------
X = df.drop('species', axis=1)   # Features
y = df['species']               # Target labels

# ---------------------------------------------
# 3. Split data into training and testing sets
# ---------------------------------------------
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=42
)

# ---------------------------------------------
# 4. Train KNN Classifier
# ---------------------------------------------
model = KNeighborsClassifier(n_neighbors=3)
model.fit(X_train, y_train)

# ---------------------------------------------
# 5. Make predictions on test data
# ---------------------------------------------
y_pred = model.predict(X_test)

# ---------------------------------------------
# 6. Print correct and wrong predictions
# ---------------------------------------------
print("Actual vs Predicted Results:\n")

for i in range(len(y_test)):
    actual = y_test.iloc[i]
    predicted = y_pred[i]

    if actual == predicted:
        print(f"Actual: {actual} | Predicted: {predicted} | CORRECT")
    else:
        print(f"Actual: {actual} | Predicted: {predicted} | WRONG")

# ---------------------------------------------
# 7. Model Accuracy
# ---------------------------------------------
print("\nModel Accuracy:")
print(model.score(X_test, y_test))

# ---------------------------------------------
# 8. Classification Report
# ---------------------------------------------
print("\nClassification Report:")
print(classification_report(y_test, y_pred))

# ---------------------------------------------
# 9. Confusion Matrix Visualization
# ---------------------------------------------
conf_mat = confusion_matrix(y_test, y_pred)

sns.heatmap(conf_mat, annot=True, fmt='d', cmap='Blues')
plt.xlabel("Predicted Label")
plt.ylabel("True Label")
plt.title("Confusion Matrix")
plt.show()
