# Linear Regression on California Housing Dataset
# -----------------------------------------------

import numpy as np
import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt
from sklearn.datasets import fetch_california_housing
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression
from sklearn.metrics import r2_score

# -------------------------------------
# 1. Import Dataset
# -------------------------------------
data = fetch_california_housing(as_frame=True)
df = data.frame

# -------------------------------------
# 2. Display first 5 rows
# -------------------------------------
print("First 5 rows:\n", df.head(), "\n")

# -------------------------------------
# 3. Number of samples (since no 'species' column)
# -------------------------------------
print("Total samples:", len(df), "\n")
print("Columns:", df.columns, "\n")

# -------------------------------------
# 4. Null values
# -------------------------------------
print("Null values:\n", df.isnull().sum(), "\n")

# -------------------------------------
# 5. Visualization
# -------------------------------------
df.hist(figsize=(12, 9))
plt.suptitle("Feature Distribution", fontsize=14)
plt.show()

plt.scatter(df["MedInc"], df["MedHouseVal"], alpha=0.3)
plt.xlabel("Median Income")
plt.ylabel("House Value")
plt.title("Income vs House Value")
plt.show()


# -------------------------------------
# 6. Covariance & Correlation
# -------------------------------------
print("Covariance Matrix:\n", df.cov(), "\n")
print("Correlation Matrix:\n", df.corr(), "\n")

# -------------------------------------
# 7. Train-Test Split
# -------------------------------------
X = df.drop("MedHouseVal", axis=1)  # all features except target
y = df["MedHouseVal"]

X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=42
)

# -------------------------------------
# 8. Apply Linear Regression
# -------------------------------------
model = LinearRegression()
model.fit(X_train, y_train)

# Predict
y_pred = model.predict(X_test)

# -------------------------------------
# 9. Accuracy (R² Score)
# -------------------------------------
r2 = r2_score(y_test, y_pred)
print("Linear Regression R2 Score (Accuracy):", r2)
