'''
Program: Logistic Regression on Iris Dataset
Steps:
1. Import dataset
2. Display first 5 rows
3. Check class sample counts
4. Check null values
5. Visualize data
6. Covariance & Correlation
7. Train-test split
8. Apply Logistic Regression
9. Predict accuracy
'''

import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt
from sklearn.datasets import load_iris
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score, confusion_matrix, classification_report

# ---------------------------------------
# 1. Import Dataset
# ---------------------------------------
iris = load_iris()
df = pd.DataFrame(iris.data, columns=iris.feature_names)
df["Species"] = iris.target

# ---------------------------------------
# 2. Display first 5 rows
# ---------------------------------------
print("First 5 rows:\n", df.head(), "\n")

# ---------------------------------------
# 3. Class sample counts
# ---------------------------------------
print("Number of samples per Species:\n", df["Species"].value_counts(), "\n")

# ---------------------------------------
# 4. Check null values
# ---------------------------------------
print("Null values:\n", df.isnull().sum(), "\n")

# ---------------------------------------
# 5. Visualizations
# ---------------------------------------
# Histogram
df.hist(figsize=(10, 8))
plt.suptitle("Feature Distributions")
plt.show()

# Scatter plot (Petal Length vs Width)
plt.scatter(df["petal length (cm)"], df["petal width (cm)"], c=df["Species"])
plt.xlabel("Petal Length")
plt.ylabel("Petal Width")
plt.title("Petal Length vs Petal Width")
plt.legend()
plt.show()

# Pairplot
sns.pairplot(df, hue="Species")
plt.show()

# ---------------------------------------
# 6. Covariance & Correlation
# ---------------------------------------
print("Covariance:\n", df.cov(), "\n")
print("Correlation:\n", df.corr(), "\n")

# ---------------------------------------
# 7. Train-test split
# ---------------------------------------
X = df.drop("Species", axis=1)
y = df["Species"]

X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=42
)

# ---------------------------------------
# 8. Apply Logistic Regression
# ---------------------------------------
model = LogisticRegression(max_iter=200)
model.fit(X_train, y_train)

# ---------------------------------------
# 9. Predict and Accuracy
# ---------------------------------------
y_pred = model.predict(X_test)
acc = accuracy_score(y_test, y_pred)

print("Accuracy:", acc)
print("\nConfusion Matrix:\n", confusion_matrix(y_test, y_pred))
print("\nClassification Report:\n", classification_report(y_test, y_pred))
