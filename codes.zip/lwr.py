import numpy as np
import matplotlib.pyplot as plt
from sklearn.metrics import r2_score,mean_squared_error


np.random.seed(0)

X=np.linspace(1,10,30)
y=np.sin(X)+np.random.normal(0,0.2,30)


print("5 Sample data points\n")
for i in range(5):
    print(f"({X[i]},{y[i]})\n")


def locally_weighted_regression(x_query,X,y,tau):
    m=len(X)
    W=np.zeros((m,m))


    for i in range(m):
        W[i,i]=np.exp(-((X[i]-x_query)**2)/(2*tau**2))
    
    X_mat=np.c_[np.ones(m),X]
    y_mat=y.reshape(-1,1)

    thetha=np.linalg.pinv(X_mat.T @ W @ X_mat) @ X_mat.T @ W @ y_mat
    x_query_mat=np.array([1,x_query])

    return x_query_mat @ thetha


tau=0.8
y_pred=np.array([locally_weighted_regression(x,X,y,tau) for x in X])

print(f"R2 SCREE -->{r2_score(y,y_pred)}")

print(f"Mean squared Error -->{mean_squared_error(y,y_pred)}")


plt.scatter(X,y,color='blue',label='Original Data')
plt.plot(X,y_pred,color='red',label='Predicted')
plt.title("comparison between actual and predicted")
plt.xlabel("X")
plt.ylabel("y")
plt.show()