'''
Program: Random Forest on California Housing Dataset
Steps:
1. Import dataset
2. Display first 5 rows
3. Check number of samples (no class labels in regression)
4. Check null values
5. Visualize data
6. Covariance & Correlation
7. Train-Test Split
8. Apply Random Forest Regression
9. Predict accuracy (R2 score)
'''

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.datasets import fetch_california_housing
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestRegressor
from sklearn.metrics import r2_score

# ---------------------------------------------
# 1. Import Dataset
# ---------------------------------------------
data = fetch_california_housing(as_frame=True)
df = data.frame

# ---------------------------------------------
# 2. Display first 5 rows
# ---------------------------------------------
print("First 5 rows:\n", df.head(), "\n")

# ---------------------------------------------
# 3. Number of samples (Regression → no species/classes)
# ---------------------------------------------
print("Total Samples:", len(df), "\n")

# ---------------------------------------------
# 4. Null values
# ---------------------------------------------
print("Null Values:\n", df.isnull().sum(), "\n")

# ---------------------------------------------
# 5. Visualizations
# ---------------------------------------------
df.hist(figsize=(12, 10))
plt.suptitle("Feature Distributions")
plt.show()

plt.scatter(df["MedInc"], df["MedHouseVal"], alpha=0.3)
plt.xlabel("Median Income")
plt.ylabel("House Value")
plt.title("Income vs House Value")
plt.show()

# ---------------------------------------------
# 6. Covariance & Correlation
# ---------------------------------------------
print("Covariance:\n", df.cov(), "\n")
print("Correlation:\n", df.corr(), "\n")

# ---------------------------------------------
# 7. Prepare Data
# ---------------------------------------------
X = df.drop("MedHouseVal", axis=1).values
y = df["MedHouseVal"].values

X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=42
)

# ---------------------------------------------
# 8. Apply Random Forest Regression
# ---------------------------------------------
model = RandomForestRegressor(n_estimators=100, random_state=42)
model.fit(X_train, y_train)

# ---------------------------------------------
# 9. Predict Accuracy
# ---------------------------------------------
y_pred = model.predict(X_test)
accuracy = r2_score(y_test, y_pred)

print("R2 Score (Accuracy):", accuracy)
