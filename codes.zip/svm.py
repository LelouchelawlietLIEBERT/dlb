from sklearn.svm import SVC
from sklearn.model_selection import train_test_split
from sklearn.metrics import classification_report
from sklearn.datasets import load_iris
from sklearn.metrics import confusion_matrix
import seaborn as sns
import matplotlib.pyplot as plt

iris=load_iris(as_frame=True)
X=iris.data
y=iris.target


X_train,X_test,y_train,y_test=train_test_split(X,y,test_size=0.3,random_state=42)

model=SVC()
model.fit(X_train,y_train)

y_pred=model.predict(X_test)

# print(y_test.unique())

print(f"model accuracy:{model.score(X_test,y_test)}")

report=classification_report(y_test,y_pred)
cmf=confusion_matrix(y_test,y_pred)

print(report)
classes=["versicolor","setosa","virginica"]
sns.heatmap(cmf,annot=True,xticklabels=classes,yticklabels=classes)
plt.show()
