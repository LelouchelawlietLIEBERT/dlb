import torch
import torch.nn as nn
import torch.optim as optim

# dummy data
x = torch.tensor([[1.0],[2.0],[3.0],[4.0]])
y = torch.tensor([[2.0],[4.0],[6.0],[8.0]])

# model
model = nn.Linear(1,1)

# loss and optimizer
criterion = nn.MSELoss()
optimizer = optim.SGD(model.parameters(), lr=0.01)

# training
for _ in range(1000):
    optimizer.zero_grad()
    y_pred = model(x)
    loss = criterion(y_pred, y)
    loss.backward()
    optimizer.step()

# output
print("weight:", model.weight.item())
print("bias:", model.bias.item())
print("prediction:", model(x).detach().numpy())
