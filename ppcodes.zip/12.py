import torch
import torch.nn as nn
import torch.optim as optim

# random data
x = torch.randn(20, 5)   # 20 samples, 5 features
y = torch.randn(20, 1)   # 20 targets

# model
model = nn.Sequential(
    nn.Linear(5,10),
    nn.ReLU(),
    nn.Linear(10,1)
)

# loss and optimizer
criterion = nn.MSELoss()
optimizer = optim.SGD(model.parameters(), lr=0.01)

# training
for _ in range(500):
    optimizer.zero_grad()
    output = model(x)
    loss = criterion(output, y)
    loss.backward()
    optimizer.step()

# output
print("prediction:\n", model(x).detach().numpy())
