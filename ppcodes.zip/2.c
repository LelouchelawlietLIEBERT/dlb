#include <stdio.h>
#include <omp.h>

int main(){
    int n=1000000;
    double pi=0.0;
    #pragma omp parallel
    {
        double x,sum=0.0;
        #pragma omp for
        for(int i=0;i<n;i++){
            x=(i+0.5)/n;
            sum+=4.0/(1.0+x*x);
        }
        #pragma omp critical
        pi+=sum;
    }
    pi/=n;
    printf("%f",pi);
    return 0;
}
