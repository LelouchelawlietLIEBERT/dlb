#include <stdio.h>
#include <omp.h>

int main(){
    int n=1000000;
    int a[n];
    long long sum=0;

    for(int i=0;i<n;i++) a[i]=1;

    double start=omp_get_wtime();
    #pragma omp parallel for reduction(+:sum)
    for(int i=0;i<n;i++) sum+=a[i];
    double end=omp_get_wtime();

    printf("sum=%lld\n",sum);
    printf("time=%f\n",end-start);
    return 0;
}
