#include <stdio.h>
#include <stdlib.h>
#include <omp.h>

int main(){
    int n = 1000000;
    int *a = malloc(n*sizeof(int));
    int *b = malloc(n*sizeof(int));
    int *c = malloc(n*sizeof(int));

    for(int i=0;i<n;i++){
        a[i]=i;
        b[i]=i;
    }

    double start = omp_get_wtime();
    #pragma omp parallel for
    for(int i=0;i<n;i++)
        c[i]=a[i]+b[i];
    double end = omp_get_wtime();

    printf("c[0]=%d\n", c[0]);
    printf("c[n-1]=%d\n", c[n-1]);
    printf("time=%f seconds\n", end-start);

    free(a);
    free(b);
    free(c);
    return 0;
}
