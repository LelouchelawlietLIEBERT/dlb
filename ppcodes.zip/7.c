#include <stdio.h>
#include <omp.h>
int main(){
    int x=0,y=0,z=0;
    #pragma omp parallel
    {
        #pragma omp single
        x=10;
        #pragma omp master
        y=20;
        #pragma omp critical
        z+=1;
    }
    printf("x=%d\n",x);
    printf("y=%d\n",y);
    printf("z=%d\n",z);
    return 0;
}
