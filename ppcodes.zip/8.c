#include <mpi.h>
#include <stdio.h>

int main(int argc,char**argv){
    MPI_Init(&argc,&argv);
    int r,s,v=0;
    MPI_Comm_rank(MPI_COMM_WORLD,&r);
    MPI_Comm_size(MPI_COMM_WORLD,&s);

    if(s > 1){
        if(r == 0){
            v = 50;
            MPI_Send(&v, 1, MPI_INT, 1, 0, MPI_COMM_WORLD);
            printf("Rank 0 sent %d\n", v);
        }
        if(r == 1){
            MPI_Recv(&v, 1, MPI_INT, 0, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
            printf("Rank 1 received %d\n", v);
        }
    } 
    else if(r == 0){
        printf("Only 1 process\n");
    }

    if(r==0) v=999;
    MPI_Bcast(&v,1,MPI_INT,0,MPI_COMM_WORLD);
    printf("Rank %d sees broadcast %d\n",r,v);

    MPI_Finalize();
    return 0;
}
